cmdFileExportSvg<-function(){
  default="unnamed.svg"
  curDir<-getCurrentDir()
  curFile<-getCurrentFile()
  if(getFileNameStatus()==TRUE){
    svgFileName<-
      paste0(tools::file_path_sans_ext(getCurrentFile()),".svg")
  } else {
    svgFileName<-"unnamed.svg"
  }
  default<-paste(curDir,svgFileName,sep="/")
  
  try({
    fileName<-dlgSave(
      default=default,
      title = "Export SVG to File", 
      filters = dlgFilters[c("R", "All"), ]
    )$res
    
    if(length(fileName)>0 && nchar(fileName)>0){
      src<- getCode()
      parsedCode<-parse(text=src)
      txt<-as.character(eval(parsedCode))
      writeLines(txt, fileName)
      if(getFileNameStatus()==FALSE){
        fileName<-sub("\\.svg$", ".R", fileName)
        setCurrentFilePath(fileName)
        
      }
    }
  })
}