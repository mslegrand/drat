# shinyDMDMenu
Shiny package for a multilevel menubar

This package provides a plugin to create a dynamic menubar capable of multiple levels in a shiny app. In addition to supporting
multi-level menus, menu items and dropdowns can be

- dynamically added and removed
- dynamically disabled and enabled
- dynamically renamed.


<img src="https://cloud.githubusercontent.com/assets/5139775/22185259/2ef71c62-e0b0-11e6-872b-2eaa67843c92.png" width="550">
