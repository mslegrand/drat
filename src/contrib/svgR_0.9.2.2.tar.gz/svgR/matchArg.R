
g<-function(x=c('a','bc','d')){
  try(
    {
      z<-match.arg(x)
      cat(z,"\n")
    }
  )
}