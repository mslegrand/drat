library(testthat)
library(svgR)

test_check("svgR")
