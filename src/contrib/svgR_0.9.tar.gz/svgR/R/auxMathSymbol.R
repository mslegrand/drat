
#' Converts a laTeX symbol specification into unicode
#' 
#' @param laTeXSymbolSpec  a laTeX symbol specification : must be one of the following
#' 
#'  \tabular{llll}{
#'  "\\\\|"                    \tab "\\\\_"                    \tab "\\\\:"                    \tab "\\\\$"                     \cr
#'   "\\\\\%"                  \tab "\\\\&"                    \tab "\\\\#"                    \tab "\\\\AC"                    \cr
#'   "\\\\acute"                \tab "\\\\aleph"                \tab "\\\\alpha"                \tab "\\\\amalg"                 \cr
#'   "\\\\anchor"               \tab "\\\\angle"                \tab "\\\\Angstroem"            \tab "\\\\APLcomment"            \cr
#'   "\\\\APLdownarrowbox"      \tab "\\\\APLinput"             \tab "\\\\APLinv"               \tab "\\\\APLleftarrowbox"       \cr
#'   "\\\\APLlog"               \tab "\\\\APLrightarrowbox"     \tab "\\\\APLuparrowbox"        \tab "\\\\approx"                \cr
#'   "\\\\approxeq"             \tab "\\\\aquarius"             \tab "\\\\aries"                \tab "\\\\arrowbullet"           \cr
#'   "\\\\ast"                  \tab "\\\\asymp"                \tab "\\\\backepsilon"          \tab "\\\\backprime"             \cr
#'   "\\\\backsim"              \tab "\\\\backsimeq"            \tab "\\\\backslash"            \tab "\\\\ballotx"               \cr
#'   "\\\\bar"                  \tab "\\\\barin"                \tab "\\\\barleftharpoon"       \tab "\\\\barrightharpoon"       \cr
#'   "\\\\barwedge"             \tab "\\\\because"              \tab "\\\\beta"                 \tab "\\\\beth"                  \cr
#'   "\\\\between"              \tab "\\\\bigcap"               \tab "\\\\bigcup"               \tab "\\\\biginterleave"         \cr
#'   "\\\\bigodot"              \tab "\\\\bigoplus"             \tab "\\\\bigotimes"            \tab "\\\\bigsqcap"              \cr
#'   "\\\\bigsqcup"             \tab "\\\\bigstar"              \tab "\\\\bigtriangledown"      \tab "\\\\bigtriangleup"         \cr
#'   "\\\\biguplus"             \tab "\\\\bigvee"               \tab "\\\\bigwedge"             \tab "\\\\bij"                   \cr
#'   "\\\\biohazard"            \tab "\\\\blacklozenge"         \tab "\\\\blacksmiley"          \tab "\\\\blacksquare"           \cr
#'   "\\\\blacktriangledown"    \tab "\\\\blacktriangleleft"    \tab "\\\\blacktriangleright"   \tab "\\\\blacktriangleup"       \cr
#'   "\\\\bot"                  \tab "\\\\Bot"                  \tab "\\\\bowtie"               \tab "\\\\boxast"                \cr
#'   "\\\\boxbar"               \tab "\\\\boxbox"               \tab "\\\\boxbslash"            \tab "\\\\boxcircle"             \cr
#'   "\\\\boxdot"               \tab "\\\\boxminus"             \tab "\\\\boxplus"              \tab "\\\\boxslash"              \cr
#'   "\\\\boxtimes"             \tab "\\\\breve"                \tab "\\\\bullet"               \tab "\\\\bumpeq"                \cr
#'   "\\\\Bumpeq"               \tab "\\\\cancer"               \tab "\\\\cap"                  \tab "\\\\Cap"                   \cr
#'   "\\\\CapitalDifferentialD" \tab "\\\\capricornus"          \tab "\\\\cat"                  \tab "\\\\cdot"                  \cr
#'   "\\\\cdots"                \tab "\\\\cent"                 \tab "\\\\check"                \tab "\\\\CheckedBox"            \cr
#'   "\\\\checkmark"            \tab "\\\\chi"                  \tab "\\\\circ"                 \tab "\\\\circeq"                \cr
#'   "\\\\Circle"               \tab "\\\\CIRCLE"               \tab "\\\\circlearrowleft"      \tab "\\\\circlearrowright"      \cr
#'   "\\\\circledast"           \tab "\\\\circledbslash"        \tab "\\\\circledcirc"          \tab "\\\\circleddash"           \cr
#'   "\\\\circledgtr"           \tab "\\\\circledless"          \tab "\\\\circledR"             \tab "\\\\clubsuit"              \cr
#'   "\\\\colon"                \tab "\\\\coloneq"              \tab "\\\\Coloneqq"             \tab "\\\\complement"            \cr
#'   "\\\\ComplexI"             \tab "\\\\ComplexJ"             \tab "\\\\cong"                 \tab "\\\\coprod"                \cr
#'   "\\\\corresponds"          \tab "\\\\cup"                  \tab "\\\\Cup"                  \tab "\\\\curlyeqprec"           \cr
#'   "\\\\curlyeqsucc"          \tab "\\\\curlyvee"             \tab "\\\\curlywedge"           \tab "\\\\curvearrowleft"        \cr
#'   "\\\\curvearrowright"      \tab "\\\\dagger"               \tab "\\\\daleth"               \tab "\\\\dashleftarrow"         \cr
#'   "\\\\dashrightarrow"       \tab "\\\\dashv"                \tab "\\\\ddagger"              \tab "\\\\ddddot"                \cr
#'   "\\\\dddot"                \tab "\\\\ddot"                 \tab "\\\\ddots"                \tab "\\\\delta"                 \cr
#'   "\\\\Delta"                \tab "\\\\diameter"             \tab "\\\\diamond"              \tab "\\\\Diamond"               \cr
#'   "\\\\Diamondblack"         \tab "\\\\Diamonddot"           \tab "\\\\diamondsuit"          \tab "\\\\DifferentialD"         \cr
#'   "\\\\digamma"              \tab "\\\\div"                  \tab "\\\\divideontimes"        \tab "\\\\dlsh"                  \cr
#'   "\\\\dot"                  \tab "\\\\doteq"                \tab "\\\\Doteq"                \tab "\\\\dotplus"               \cr
#'   "\\\\doublebarwedge"       \tab "\\\\downarrow"            \tab "\\\\Downarrow"            \tab "\\\\DownArrowBar"          \cr
#'   "\\\\downdownarrows"       \tab "\\\\downdownharpoons"     \tab "\\\\downharpoonleft"      \tab "\\\\downharpoonright"      \cr
#'   "\\\\DownLeftTeeVector"    \tab "\\\\DownLeftVectorBar"    \tab "\\\\DownRightTeeVector"   \tab "\\\\DownRightVectorBar"    \cr
#'   "\\\\downuparrows"         \tab "\\\\downupharpoons"       \tab "\\\\drsh"                 \tab "\\\\dsub"                  \cr
#'   "\\\\earth"                \tab "\\\\eighthnote"           \tab "\\\\ell"                  \tab "\\\\epsilon"               \cr
#'   "\\\\eqcirc"               \tab "\\\\eqcolon"              \tab "\\\\eqsim"                \tab "\\\\eqslantgtr"            \cr
#'   "\\\\eqslantless"          \tab "\\\\Equal"                \tab "\\\\equiv"                \tab "\\\\eta"                   \cr
#'   "\\\\eth"                  \tab "\\\\Euler"                \tab "\\\\exists"               \tab "\\\\ExponetialE"           \cr
#'   "\\\\fallingdotseq"        \tab "\\\\fcmp"                 \tab "\\\\female"               \tab "\\\\ffun"                  \cr
#'   "\\\\finj"                 \tab "\\\\fint"                 \tab "\\\\Finv"                 \tab "\\\\flat"                  \cr
#'   "\\\\forall"               \tab "\\\\fourth"               \tab "\\\\frown"                \tab "\\\\frownie"               \cr
#'   "\\\\gamma"                \tab "\\\\Gamma"                \tab "\\\\gemini"               \tab "\\\\geq"                   \cr
#'   "\\\\geqq"                 \tab "\\\\geqslant"             \tab "\\\\gg"                   \tab "\\\\ggcurly"               \cr
#'   "\\\\ggg"                  \tab "\\\\gimel"                \tab "\\\\gnapprox"             \tab "\\\\gneq"                  \cr
#'   "\\\\gneqq"                \tab "\\\\gnsim"                \tab "\\\\grave"                \tab "\\\\gtrapprox"             \cr
#'   "\\\\gtrdot"               \tab "\\\\gtreqless"            \tab "\\\\gtreqqless"           \tab "\\\\gtrless"               \cr
#'   "\\\\gtrsim"               \tab "\\\\hash"                 \tab "\\\\hat"                  \tab "\\\\heartsuit"             \cr
#'   "\\\\hookleftarrow"        \tab "\\\\hookrightarrow"       \tab "\\\\hslash"               \tab "\\\\iddots"                \cr
#'   "\\\\iiiint"               \tab "\\\\iiint"                \tab "\\\\iint"                 \tab "\\\\Im"                    \cr
#'   "\\\\imath"                \tab "\\\\in"                   \tab "\\\\infty"                \tab "\\\\int"                   \cr
#'   "\\\\intercal"             \tab "\\\\interleave"           \tab "\\\\invamp"               \tab "\\\\invneg"                \cr
#'   "\\\\iota"                 \tab "\\\\jmath"                \tab "\\\\Join"                 \tab "\\\\jupiter"               \cr
#'   "\\\\kappa"                \tab "\\\\koppa"                \tab "\\\\Koppa"                \tab "\\\\lambda"                \cr
#'   "\\\\Lambda"               \tab "\\\\lang"                 \tab "\\\\langle"               \tab "\\\\Lbag"                  \cr
#'   "\\\\lblot"                \tab "\\\\lbrack"               \tab "\\\\lceil"                \tab "\\\\ldots"                 \cr
#'   "\\\\leadsto"              \tab "\\\\leftarrow"            \tab "\\\\Leftarrow"            \tab "\\\\LeftArrowBar"          \cr
#'   "\\\\leftarrowtail"        \tab "\\\\leftarrowtriangle"    \tab "\\\\leftbarharpoon"       \tab "\\\\LEFTcircle"            \cr
#'   "\\\\LEFTCIRCLE"           \tab "\\\\LeftDownTeeVector"    \tab "\\\\LeftDownVectorBar"    \tab "\\\\leftharpoondown"       \cr
#'   "\\\\leftharpoonup"        \tab "\\\\leftleftarrows"       \tab "\\\\leftleftharpoons"     \tab "\\\\leftmoon"              \cr
#'   "\\\\leftrightarrow"       \tab "\\\\Leftrightarrow"       \tab "\\\\leftrightarrows"      \tab "\\\\leftrightarrowtriangle"\cr
#'   "\\\\leftrightharpoon"     \tab "\\\\leftrightharpoondown" \tab "\\\\leftrightharpoons"    \tab "\\\\leftrightharpoonup"    \cr
#'   "\\\\leftrightsquigarrow"  \tab "\\\\leftslice"            \tab "\\\\leftsquigarrow"       \tab "\\\\LeftTeeVector"         \cr
#'   "\\\\leftthreetimes"       \tab "\\\\LeftTriangleBar"      \tab "\\\\leftupdownharpoon"    \tab "\\\\LeftUpTeeVector"       \cr
#'   "\\\\LeftUpVectorBar"      \tab "\\\\LeftVectorBar"        \tab "\\\\leo"                  \tab "\\\\leq"                   \cr
#'   "\\\\leqq"                 \tab "\\\\leqslant"             \tab "\\\\lessapprox"           \tab "\\\\lessdot"               \cr
#'   "\\\\lesseqgtr"            \tab "\\\\lesseqqgtr"           \tab "\\\\lessgtr"              \tab "\\\\lesssim"               \cr
#'   "\\\\lfloor"               \tab "\\\\lgroup"               \tab "\\\\lhd"                  \tab "\\\\LHD"                   \cr
#'   "\\\\libra"                \tab "\\\\lightning"            \tab "\\\\limg"                 \tab "\\\\ll"                    \cr
#'   "\\\\llbracket"            \tab "\\\\llcorner"             \tab "\\\\llcurly"              \tab "\\\\Lleftarrow"            \cr
#'   "\\\\lll"                  \tab "\\\\lnapprox"             \tab "\\\\lneq"                 \tab "\\\\lneqq"                 \cr
#'   "\\\\lnsim"                \tab "\\\\longleftarrow"        \tab "\\\\Longleftarrow"        \tab "\\\\longleftrightarrow"    \cr
#'   "\\\\Longleftrightarrow"   \tab "\\\\longmapsfrom"         \tab "\\\\Longmapsfrom"         \tab "\\\\longmapsto"            \cr
#'   "\\\\Longmapsto"           \tab "\\\\longrightarrow"       \tab "\\\\Longrightarrow"       \tab "\\\\looparrowleft"         \cr
#'   "\\\\looparrowright"       \tab "\\\\lozenge"              \tab "\\\\Lparen"               \tab "\\\\lrcorner"              \cr
#'   "\\\\Lsh"                  \tab "\\\\ltimes"               \tab "\\\\lvec"                 \tab "\\\\LVec"                  \cr
#'   "\\\\male"                 \tab "\\\\maltese"              \tab "\\\\MapsDown"             \tab "\\\\mapsfrom"              \cr
#'   "\\\\Mapsfrom"             \tab "\\\\mapsto"               \tab "\\\\Mapsto"               \tab "\\\\MapsUp"                \cr
#'   "\\\\mathring"             \tab "\\\\measuredangle"        \tab "\\\\medbullet"            \tab "\\\\medcirc"               \cr
#'   "\\\\mercury"              \tab "\\\\mho"                  \tab "\\\\Micro"                \tab "\\\\mid"                   \cr
#'   "\\\\models"               \tab "\\\\mp"                   \tab "\\\\mu"                   \tab "\\\\multimap"              \cr
#'   "\\\\multimapboth"         \tab "\\\\multimapdotbothA"     \tab "\\\\multimapdotbothB"     \tab "\\\\multimapinv"           \cr
#'   "\\\\nabla"                \tab "\\\\napprox"              \tab "\\\\natural"              \tab "\\\\ncong"                 \cr
#'   "\\\\nearrow"              \tab "\\\\Nearrow"              \tab "\\\\neg"                  \tab "\\\\neptune"               \cr
#'   "\\\\neq"                  \tab "\\\\nequiv"               \tab "\\\\NestedGreaterGreater" \tab "\\\\NestedLessLess"        \cr
#'   "\\\\nexists"              \tab "\\\\ngeq"                 \tab "\\\\ngtr"                 \tab "\\\\ni"                    \cr
#'   "\\\\nleftarrow"           \tab "\\\\nLeftarrow"           \tab "\\\\nleftrightarrow"      \tab "\\\\nLeftrightarrow"       \cr
#'   "\\\\nleq"                 \tab "\\\\nless"                \tab "\\\\nmid"                 \tab "\\\\nni"                   \cr
#'   "\\\\not"                  \tab "\\\\notasymp"             \tab "\\\\notbackslash"         \tab "\\\\NotGreaterLess"        \cr
#'   "\\\\NotGreaterTilde"      \tab "\\\\notin"                \tab "\\\\NotLessTilde"         \tab "\\\\notslash"              \cr
#'   "\\\\nparallel"            \tab "\\\\nprec"                \tab "\\\\npreceq"              \tab "\\\\nrightarrow"           \cr
#'   "\\\\nRightarrow"          \tab "\\\\nsim"                 \tab "\\\\nsimeq"               \tab "\\\\nsqsubseteq"           \cr
#'   "\\\\nsqsupseteq"          \tab "\\\\nsubset"              \tab "\\\\nsubseteq"            \tab "\\\\nsucc"                 \cr
#'   "\\\\nsucceq"              \tab "\\\\nsupset"              \tab "\\\\nsupseteq"            \tab "\\\\ntriangleleft"         \cr
#'   "\\\\ntrianglelefteq"      \tab "\\\\ntriangleright"       \tab "\\\\ntrianglerighteq"     \tab "\\\\nu"                    \cr
#'   "\\\\nvdash"               \tab "\\\\nvDash"               \tab "\\\\nVdash"               \tab "\\\\nVDash"                \cr
#'   "\\\\nwarrow"              \tab "\\\\Nwarrow"              \tab "\\\\odot"                 \tab "\\\\oiiint"                \cr
#'   "\\\\oiint"                \tab "\\\\oint"                 \tab "\\\\ointctrclockwise"     \tab "\\\\omega"                 \cr
#'   "\\\\Omega"                \tab "\\\\ominus"               \tab "\\\\oplus"                \tab "\\\\oslash"                \cr
#'   "\\\\otimes"               \tab "\\\\overbrace"            \tab "\\\\overleftrightarrow"   \tab "\\\\overline"              \cr
#'   "\\\\overparen"            \tab "\\\\parallel"             \tab "\\\\partialup"            \tab "\\\\pencil"                \cr
#'   "\\\\perp"                 \tab "\\\\pfun"                 \tab "\\\\phi"                  \tab "\\\\Phi"                   \cr
#'   "\\\\pi"                   \tab "\\\\Pi"                   \tab "\\\\pinj"                 \tab "\\\\pisces"                \cr
#'   "\\\\pitchfork"            \tab "\\\\pluto"                \tab "\\\\pm"                   \tab "\\\\pointright"            \cr
#'   "\\\\pounds"               \tab "\\\\prec"                 \tab "\\\\precapprox"           \tab "\\\\preccurlyeq"           \cr
#'   "\\\\preceq"               \tab "\\\\preceqq"              \tab "\\\\precnapprox"          \tab "\\\\precnsim"              \cr
#'   "\\\\precsim"              \tab "\\\\prime"                \tab "\\\\prod"                 \tab "\\\\Proportion"            \cr
#'   "\\\\propto"               \tab "\\\\psi"                  \tab "\\\\Psi"                  \tab "\\\\psur"                  \cr
#'   "\\\\qoppa"                \tab "\\\\Qoppa"                \tab "\\\\quad"                 \tab "\\\\quarternote"           \cr
#'   "\\\\radiation"            \tab "\\\\rang"                 \tab "\\\\rangle"               \tab "\\\\Rbag"                  \cr
#'   "\\\\rblot"                \tab "\\\\rbrack"               \tab "\\\\rceil"                \tab "\\\\Re"                    \cr
#'   "\\\\recycle"              \tab "\\\\rfloor"               \tab "\\\\rgroup"               \tab "\\\\rhd"                   \cr
#'   "\\\\RHD"                  \tab "\\\\rho"                  \tab "\\\\rightangle"           \tab "\\\\rightarrow"            \cr
#'   "\\\\Rightarrow"           \tab "\\\\RightArrowBar"        \tab "\\\\rightarrowtail"       \tab "\\\\rightarrowtriangle"    \cr
#'   "\\\\rightbarharpoon"      \tab "\\\\RIGHTcircle"          \tab "\\\\RIGHTCIRCLE"          \tab "\\\\RightDownTeeVector"    \cr
#'   "\\\\RightDownVectorBar"   \tab "\\\\rightharpoondown"     \tab "\\\\rightharpoonup"       \tab "\\\\rightleftarrows"       \cr
#'   "\\\\rightleftharpoon"     \tab "\\\\rightleftharpoons"    \tab "\\\\rightmoon"            \tab "\\\\rightrightarrows"      \cr
#'   "\\\\rightrightharpoons"   \tab "\\\\rightslice"           \tab "\\\\rightsquigarrow"      \tab "\\\\RightTeeVector"        \cr
#'   "\\\\rightthreetimes"      \tab "\\\\RightTriangleBar"     \tab "\\\\rightupdownharpoon"   \tab "\\\\RightUpTeeVector"      \cr
#'   "\\\\RightUpVectorBar"     \tab "\\\\RightVectorBar"       \tab "\\\\rimg"                 \tab "\\\\risingdotseq"          \cr
#'   "\\\\Rparen"               \tab "\\\\rrbracket"            \tab "\\\\Rrightarrow"          \tab "\\\\Rsh"                   \cr
#'   "\\\\rsub"                 \tab "\\\\rtimes"               \tab "\\\\sagittarius"          \tab "\\\\Same"                  \cr
#'   "\\\\sampi"                \tab "\\\\Sampi"                \tab "\\\\saturn"               \tab "\\\\scorpio"               \cr
#'   "\\\\searrow"              \tab "\\\\Searrow"              \tab "\\\\second"               \tab "\\\\setminus"              \cr
#'   "\\\\sharp"                \tab "\\\\sigma"                \tab "\\\\Sigma"                \tab "\\\\sim"                   \cr
#'   "\\\\simeq"                \tab "\\\\sixteenthnote"        \tab "\\\\skull"                \tab "\\\\slash"                 \cr
#'   "\\\\smallsetminus"        \tab "\\\\smalltriangledown"    \tab "\\\\smalltriangleleft"    \tab "\\\\smalltriangleright"    \cr
#'   "\\\\smalltriangleup"      \tab "\\\\smile"                \tab "\\\\smiley"               \tab "\\\\spadesuit"             \cr
#'   "\\\\sphat"                \tab "\\\\sphericalangle"       \tab "\\\\spot"                 \tab "\\\\sptilde"               \cr
#'   "\\\\sqcap"                \tab "\\\\sqcup"                \tab "\\\\sqint"                \tab "\\\\sqrt"                  \cr
#'   "\\\\sqrt[3]"              \tab "\\\\sqrt[4]"              \tab "\\\\sqsubset"             \tab "\\\\sqsubseteq"            \cr
#'   "\\\\sqsupset"             \tab "\\\\sqsupseteq"           \tab "\\\\square"               \tab "\\\\Square"                \cr
#'   "\\\\sslash"               \tab "\\\\star"                 \tab "\\\\steaming"             \tab "\\\\stigma"                \cr
#'   "\\\\Stigma"               \tab "\\\\strictfi"             \tab "\\\\strictif"             \tab "\\\\subset"                \cr
#'   "\\\\Subset"               \tab "\\\\subseteq"             \tab "\\\\subseteqq"            \tab "\\\\subsetneq"             \cr
#'   "\\\\subsetneqq"           \tab "\\\\succ"                 \tab "\\\\succapprox"           \tab "\\\\succcurlyeq"           \cr
#'   "\\\\succeq"               \tab "\\\\succeqq"              \tab "\\\\succnapprox"          \tab "\\\\succnsim"              \cr
#'   "\\\\succsim"              \tab "\\\\sum"                  \tab "\\\\sun"                  \tab "\\\\Sun"                   \cr
#'   "\\\\supset"               \tab "\\\\Supset"               \tab "\\\\supseteq"             \tab "\\\\supseteqq"             \cr
#'   "\\\\supsetneq"            \tab "\\\\supsetneqq"           \tab "\\\\swarrow"              \tab "\\\\Swarrow"               \cr
#'   "\\\\swords"               \tab "\\\\talloblong"           \tab "\\\\tau"                  \tab "\\\\taurus"                \cr
#'   "\\\\tcohm"                \tab "\\\\therefore"            \tab "\\\\theta"                \tab "\\\\Theta"                 \cr
#'   "\\\\third"                \tab "\\\\tilde"                \tab "\\\\times"                \tab "\\\\top"                   \cr
#'   "\\\\Top"                  \tab "\\\\trianglelefteq"       \tab "\\\\triangleq"            \tab "\\\\trianglerighteq"       \cr
#'   "\\\\twoheadleftarrow"     \tab "\\\\twoheadrightarrow"    \tab "\\\\twonotes"             \tab "\\\\ulcorner"              \cr
#'   "\\\\underbar"             \tab "\\\\underbrace"           \tab "\\\\underleftarrow"       \tab "\\\\underline"             \cr
#'   "\\\\underparen"           \tab "\\\\underrightarrow"      \tab "\\\\uparrow"              \tab "\\\\Uparrow"               \cr
#'   "\\\\UpArrowBar"           \tab "\\\\updownarrow"          \tab "\\\\Updownarrow"          \tab "\\\\updownarrows"          \cr
#'   "\\\\updownharpoons"       \tab "\\\\upharpoonleft"        \tab "\\\\upharpoonright"       \tab "\\\\uplus"                 \cr
#'   "\\\\upsilon"              \tab "\\\\Upsilon"              \tab "\\\\upuparrows"           \tab "\\\\upupharpoons"          \cr
#'   "\\\\uranus"               \tab "\\\\urcorner"             \tab "\\\\utilde"               \tab "\\\\varbeta"               \cr
#'   "\\\\varclubsuit"          \tab "\\\\vardiamondsuit"       \tab "\\\\varepsilon"           \tab "\\\\varheartsuit"          \cr
#'   "\\\\varnothing"           \tab "\\\\varointclockwise"     \tab "\\\\varphi"               \tab "\\\\varpi"                 \cr
#'   "\\\\varprod"              \tab "\\\\varrho"               \tab "\\\\varsigma"             \tab "\\\\varspadesuit"          \cr
#'   "\\\\vartheta"             \tab "\\\\vartriangleleft"      \tab "\\\\vartriangleright"     \tab "\\\\vdash"                 \cr
#'   "\\\\vDash"                \tab "\\\\Vdash"                \tab "\\\\VDash"                \tab "\\\\vdots"                 \cr
#'   "\\\\vec"                  \tab "\\\\vee"                  \tab "\\\\veebar"               \tab "\\\\VERT"                  \cr
#'   "\\\\virgo"                \tab "\\\\Vvdash"               \tab "\\\\warning"              \tab "\\\\wasylozenge"           \cr
#'   "\\\\wedge"                \tab "\\\\wp"                   \tab "\\\\wr"                   \tab "\\\\XBox"                  \cr
#'   "\\\\xi"                   \tab "\\\\Xi"                   \tab "\\\\yen"                  \tab "\\\\yinyang"               \cr
#'   "\\\\Yup"                  \tab "\\\\zcmp"                 \tab "\\\\zeta"                 \tab "\\\\zhide"                 \cr
#'   "\\\\zpipe"                \tab "\\\\zproject"             \tab                                \tab                                 
#'  }
#' @return unicode character
#' 
#' @export
mathSymbol<-function(laTeXSymbolSpec){
 if( laTeXSymbolSpec %in% names(TeXUniCode ) ) {
   TeXUniCode[laTeXSymbolSpec]
 } else {
   base::stop("laTeX symbol not supported")
 }
}
