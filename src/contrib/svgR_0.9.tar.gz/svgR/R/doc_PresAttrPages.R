#' @name writing-mode-presentationAttribute
#' @title writing.mode
#' @description 
#' Sets the initial inline-progression-direction
#' @section Available Attribute Values:
#' \itemize{
#' \item{lr-tb}{**ToDo!!!** }
#' \item{rl-tb}{**ToDo!!!** }
#' \item{tb-rl}{**ToDo!!!** }
#' \item{lr}{**ToDo!!!** }
#' \item{rl}{**ToDo!!!** }
#' \item{tb}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=text]{text}}}
#' }
#' @keywords internal
NULL


#' @name glyph-orientation-vertical-presentationAttribute
#' @title glyph.orientation.vertical
#' @description 
#' controls glyph orientation when the inline-progression-direction is vertical
#' @section Available Attribute Values:
#' \itemize{
#' \item{auto}{**ToDo!!!** }
#' \item{<angle>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name glyph-orientation-horizontal-presentationAttribute
#' @title glyph.orientation.horizontal
#' @description 
#' controls glyph orientation when the inline-progression-direction is horizontal
#' @section Available Attribute Values:
#' \itemize{
#' \item{<angle>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name direction-presentationAttribute
#' @title direction
#' @description 
#' specifies the base writing direction of text
#' @section Available Attribute Values:
#' \itemize{
#' \item{ltr}{**ToDo!!!** }
#' \item{rtl}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name unicode-bidi-presentationAttribute
#' @title unicode.bidi
#' @description 
#' Specifies  text in a single line to appear with mixed directionality
#' @section Available Attribute Values:
#' \itemize{
#' \item{normal}{**ToDo!!!** }
#' \item{embed}{**ToDo!!!** }
#' \item{bidi-override}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name text-anchor-presentationAttribute
#' @title text.anchor
#' @description 
#'  Specifies alignment (start-, middle- or end-alignment) a string of text relative to a given point
#' @section Available Attribute Values:
#' \itemize{
#' \item{start}{**ToDo!!!** }
#' \item{middle}{**ToDo!!!** }
#' \item{end}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name dominant-baseline-presentationAttribute
#' @title dominant.baseline
#' @description 
#' Specifies baseline table established at the start of processing of a ‘text’ element
#' @section Available Attribute Values:
#' \itemize{
#' \item{auto}{**ToDo!!!** }
#' \item{use-script}{**ToDo!!!** }
#' \item{no-change}{**ToDo!!!** }
#' \item{reset-size}{**ToDo!!!** }
#' \item{ideographic}{**ToDo!!!** }
#' \item{alphabetic}{**ToDo!!!** }
#' \item{hanging}{**ToDo!!!** }
#' \item{mathematical}{**ToDo!!!** }
#' \item{central}{**ToDo!!!** }
#' \item{middle}{**ToDo!!!** }
#' \item{text-after-edge}{**ToDo!!!** }
#' \item{text-before-edge}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name alignment-baseline-presentationAttribute
#' @title alignment.baseline
#' @description 
#'  Determines or re-determines a scaled-baseline-table
#' @section Available Attribute Values:
#' \itemize{
#' \item{auto}{**ToDo!!!** }
#' \item{baseline}{**ToDo!!!** }
#' \item{before-edge}{**ToDo!!!** }
#' \item{text-before-edge}{**ToDo!!!** }
#' \item{middle}{**ToDo!!!** }
#' \item{central}{**ToDo!!!** }
#' \item{after-edge}{**ToDo!!!** }
#' \item{text-after-edge}{**ToDo!!!** }
#' \item{ideographic}{**ToDo!!!** }
#' \item{alphabetic}{**ToDo!!!** }
#' \item{hanging}{**ToDo!!!** }
#' \item{mathematical}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name baseline-shift-presentationAttribute
#' @title baseline.shift
#' @description 
#' Specifies which baseline of this element is to be aligned with the corresponding baseline of the parent
#' @section Available Attribute Values:
#' \itemize{
#' \item{baseline}{**ToDo!!!** }
#' \item{sub}{**ToDo!!!** }
#' \item{super}{**ToDo!!!** }
#' \item{<percentage>}{**ToDo!!!** }
#' \item{<length>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name font-family-presentationAttribute
#' @title font.family
#' @description 
#' Specifies a prioritized list of which font family to be used to render text
#' @section Available Attribute Values:
#' \itemize{
#' \item{[[ <family-name> | <generic-family> ],]* [<family-name> | <generic-family>] | inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name font-style-presentationAttribute
#' @title font.style
#' @description 
#' Specifies whether the text is to be rendered using a normal, italic or oblique face.
#' @section Available Attribute Values:
#' \itemize{
#' \item{normal}{**ToDo!!!** }
#' \item{italic}{**ToDo!!!** }
#' \item{oblique}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name font-variant-presentationAttribute
#' @title font.variant
#' @description 
#' Specifies  whether the text is to be rendered using the normal glyphs for lowercase characters or using small-caps glyphs for lowercase characters
#' @section Available Attribute Values:
#' \itemize{
#' \item{normal}{**ToDo!!!** }
#' \item{small-caps}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name font-weight-presentationAttribute
#' @title font.weight
#' @description 
#' Specifies boldness or lightness of the glyphs used to render the text
#' @section Available Attribute Values:
#' \itemize{
#' \item{normal}{**ToDo!!!** }
#' \item{bold}{**ToDo!!!** }
#' \item{bolder}{**ToDo!!!** }
#' \item{lighter}{**ToDo!!!** }
#' \item{100}{**ToDo!!!** }
#' \item{200}{**ToDo!!!** }
#' \item{300}{**ToDo!!!** }
#' \item{400}{**ToDo!!!** }
#' \item{500}{**ToDo!!!** }
#' \item{600}{**ToDo!!!** }
#' \item{700}{**ToDo!!!** }
#' \item{800}{**ToDo!!!** }
#' \item{900}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name font-stretch-presentationAttribute
#' @title font.stretch
#' @description 
#' Specifies  the desired amount of condensing or expansion in the glyphs used to render the text.
#' @section Available Attribute Values:
#' \itemize{
#' \item{normal}{**ToDo!!!** }
#' \item{wider}{**ToDo!!!** }
#' \item{narrower}{**ToDo!!!** }
#' \item{ultra-condensed}{**ToDo!!!** }
#' \item{extra-condensed}{**ToDo!!!** }
#' \item{condensed}{**ToDo!!!** }
#' \item{semi-condensed}{**ToDo!!!** }
#' \item{semi-expanded}{**ToDo!!!** }
#' \item{expanded}{**ToDo!!!** }
#' \item{extra-expanded}{**ToDo!!!** }
#' \item{ultra-expanded}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name font-size-presentationAttribute
#' @title font.size
#' @description 
#' Specifies  size of the font from baseline to baseline when multiple lines of text are set solid in a multiline layout environment.
#' @section Available Attribute Values:
#' \itemize{
#' \item{<absolute-size>}{**ToDo!!!** }
#' \item{<relative-size>}{**ToDo!!!** }
#' \item{<length>}{**ToDo!!!** }
#' \item{<percentage>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name font-size-adjust-presentationAttribute
#' @title font.size.adjust
#' @description 
#' Specifies specify an aspect value for an element that will preserve the x-height of the first choice font in a substitute font.
#' @section Available Attribute Values:
#' \itemize{
#' \item{<number>}{**ToDo!!!** }
#' \item{none}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name font-presentationAttribute
#' @title font
#' @description 
#' Shorthand property for setting ‘font-style’, ‘font-variant’, ‘font-weight’, ‘font-size’, ‘line-height’ and ‘font-family’.
#' @section Available Attribute Values:
#' \itemize{
#' \item{[ [ <'font-style'> || <'font-variant'> || <'font-weight'> ]? <'font-size'> [ / <'line-height'> ]? <'font-family'> ] | caption | icon | menu | message-box | small-caption | status-bar | inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name kerning-presentationAttribute
#' @title kerning
#' @description 
#' Specifies any  adjust inter-glyph spacing based on kerning tables that are included in the current font
#' @section Available Attribute Values:
#' \itemize{
#' \item{auto}{**ToDo!!!** }
#' \item{<length>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name letter-spacing-presentationAttribute
#' @title letter.spacing
#' @description 
#' Specifies spacing behavior between text characters supplemental to any spacing due to the ‘kerning’ property.
#' @section Available Attribute Values:
#' \itemize{
#' \item{normal}{**ToDo!!!** }
#' \item{<length>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name word-spacing-presentationAttribute
#' @title word.spacing
#' @description 
#' Specifies spacing behavior between words.
#' @section Available Attribute Values:
#' \itemize{
#' \item{normal}{**ToDo!!!** }
#' \item{<length>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name text-decoration-presentationAttribute
#' @title text.decoration
#' @description 
#' Specifies decorations that are added to the text of an element.  (Such as blinking)
#' @section Available Attribute Values:
#' \itemize{
#' \item{none | [ underline || overline || line-through || blink ] | inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name overflow-presentationAttribute
#' @title overflow
#' @description 
#' Specifies behaviour element when it overflows its viewport (such as scroll, hidden, …)
#' @section Available Attribute Values:
#' \itemize{
#' \item{visible}{**ToDo!!!** }
#' \item{hidden}{**ToDo!!!** }
#' \item{scroll}{**ToDo!!!** }
#' \item{auto}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Graphics Referencing Elements}}{\code{\link[=image]{image}}}
#' \item{\emph{Non-structural Container Elements}}{\code{\link[=marker]{marker}}, \code{\link[=pattern]{pattern}}}
#' \item{\emph{Structural Container Elements}}{\code{\link[=svg]{svg}}, \code{\link[=symbol]{symbol}}}
#' \item{\emph{Uncategorized Elements}}{\code{\link[=foreignObject]{foreignObject}}}
#' }
#' @keywords internal
NULL


#' @name clip-presentationAttribute
#' @title clip
#' @description 
#' Specifies whether to clip by shape,  auto, or inherit from container.
#' @section Available Attribute Values:
#' \itemize{
#' \item{<shape>}{**ToDo!!!** }
#' \item{auto}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Graphics Referencing Elements}}{\code{\link[=image]{image}}}
#' \item{\emph{Non-structural Container Elements}}{\code{\link[=marker]{marker}}, \code{\link[=pattern]{pattern}}}
#' \item{\emph{Structural Container Elements}}{\code{\link[=svg]{svg}}, \code{\link[=symbol]{symbol}}}
#' \item{\emph{Uncategorized Elements}}{\code{\link[=foreignObject]{foreignObject}}}
#' }
#' @keywords internal
NULL


#' @name clip-path-presentationAttribute
#' @title clip.path
#' @description 
#' Specifies path for clipping.
#' @section Available Attribute Values:
#' \itemize{
#' \item{<funciri>}{**ToDo!!!** }
#' \item{none}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Graphics Referencing Elements}}{\code{\link[=image]{image}}, \code{\link[=use]{use}}}
#' \item{\emph{Non-structural Container Elements}}{\code{\link[=a]{a}}, \code{\link[=glyph]{glyph}}, \code{\link[=marker]{marker}}, \code{\link[=mask]{mask}}, \code{\link[=missing-glyph]{missing.glyph}}, \code{\link[=pattern]{pattern}}, \code{\link[=switch]{switch}}}
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Structural Container Elements}}{\code{\link[=defs]{defs}}, \code{\link[=g]{g}}, \code{\link[=svg]{svg}}, \code{\link[=symbol]{symbol}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=text]{text}}}
#' \item{\emph{Uncategorized Elements}}{\code{\link[=clipPath]{clipPath}}}
#' }
#' @keywords internal
NULL


#' @name clip-rule-presentationAttribute
#' @title clip.rule
#' @description 
#' Specifies whether to use an even-odd rule for clipping
#' @section Available Attribute Values:
#' \itemize{
#' \item{nonzero}{**ToDo!!!** }
#' \item{evenodd}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Graphics Referencing Elements}}{\code{\link[=image]{image}}, \code{\link[=use]{use}}}
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=text]{text}}}
#' }
#' @keywords internal
NULL


#' @name mask-presentationAttribute
#' @title mask
#' @description 
#' Specifies what to use for masking
#' @section Available Attribute Values:
#' \itemize{
#' \item{<funciri>}{**ToDo!!!** }
#' \item{none}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Graphics Referencing Elements}}{\code{\link[=image]{image}}, \code{\link[=use]{use}}}
#' \item{\emph{Non-structural Container Elements}}{\code{\link[=a]{a}}, \code{\link[=glyph]{glyph}}, \code{\link[=marker]{marker}}, \code{\link[=mask]{mask}}, \code{\link[=missing-glyph]{missing.glyph}}, \code{\link[=pattern]{pattern}}, \code{\link[=switch]{switch}}}
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Structural Container Elements}}{\code{\link[=defs]{defs}}, \code{\link[=g]{g}}, \code{\link[=svg]{svg}}, \code{\link[=symbol]{symbol}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=text]{text}}}
#' }
#' @keywords internal
NULL


#' @name opacity-presentationAttribute
#' @title opacity
#' @description 
#' Specifies opacity.
#' @section Available Attribute Values:
#' \itemize{
#' \item{<opacity-value>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Graphics Referencing Elements}}{\code{\link[=image]{image}}, \code{\link[=use]{use}}}
#' \item{\emph{Non-structural Container Elements}}{\code{\link[=a]{a}}, \code{\link[=glyph]{glyph}}, \code{\link[=marker]{marker}}, \code{\link[=missing-glyph]{missing.glyph}}, \code{\link[=pattern]{pattern}}, \code{\link[=switch]{switch}}}
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Structural Container Elements}}{\code{\link[=defs]{defs}}, \code{\link[=g]{g}}, \code{\link[=svg]{svg}}, \code{\link[=symbol]{symbol}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=text]{text}}}
#' }
#' @keywords internal
NULL


#' @name fill-presentationAttribute
#' @title fill
#' @description 
#' Specifies the paints used to fill the interior of a given graphical element.
#' @section Available Attribute Values:
#' \itemize{
#' \item{<paint> (See Specifying paint)}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name fill-rule-presentationAttribute
#' @title fill.rule
#' @description 
#' Specifies algorithm to use for determining what is consider  interior when filling.
#' @section Available Attribute Values:
#' \itemize{
#' \item{nonzero}{**ToDo!!!** }
#' \item{evenodd}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name fill-opacity-presentationAttribute
#' @title fill.opacity
#' @description 
#' Specifies the opacity of the painting operation used to paint the interior the current object.
#' @section Available Attribute Values:
#' \itemize{
#' \item{<opacity-value>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name stroke-presentationAttribute
#' @title stroke
#' @description 
#' Specifies the paint used for the outline of the given graphical element
#' @section Available Attribute Values:
#' \itemize{
#' \item{<paint> (See Specifying paint)}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name stroke-width-presentationAttribute
#' @title stroke.width
#' @description 
#' Specifies the width of the stroke on the current object.
#' @section Available Attribute Values:
#' \itemize{
#' \item{<percentage>}{**ToDo!!!** }
#' \item{<length>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name stroke-linecap-presentationAttribute
#' @title stroke.linecap
#' @description 
#' Specifies the shape to be used at the end of open subpaths when they are stroked.
#' @section Available Attribute Values:
#' \itemize{
#' \item{butt}{**ToDo!!!** }
#' \item{round}{**ToDo!!!** }
#' \item{square}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name stroke-linejoin-presentationAttribute
#' @title stroke.linejoin
#' @description 
#' To do
#' @section Available Attribute Values:
#' \itemize{
#' \item{miter}{**ToDo!!!** }
#' \item{round}{**ToDo!!!** }
#' \item{bevel}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name stroke-miterlimit-presentationAttribute
#' @title stroke.miterlimit
#' @description 
#' Specifies a limit on the ratio of the miter length to the ‘stroke-width.
#' @section Available Attribute Values:
#' \itemize{
#' \item{<miterlimit>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name stroke-dasharray-presentationAttribute
#' @title stroke.dasharray
#' @description 
#' Specifies the pattern of dashes and gaps used to stroke paths.
#' @section Available Attribute Values:
#' \itemize{
#' \item{none}{**ToDo!!!** }
#' \item{<dasharray>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name stroke-dashoffset-presentationAttribute
#' @title stroke.dashoffset
#' @description 
#' Specifies the distance into the dash pattern to start the dash.
#' @section Available Attribute Values:
#' \itemize{
#' \item{<percentage>}{**ToDo!!!** }
#' \item{<length>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name stroke-opacity-presentationAttribute
#' @title stroke.opacity
#' @description 
#' Specifies the opacity of the painting operation used to stroke the current object.
#' @section Available Attribute Values:
#' \itemize{
#' \item{<opacity-value>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name display-presentationAttribute
#' @title display
#' @description 
#' Specifies whether an element or container will be rendered.
#' @section Available Attribute Values:
#' \itemize{
#' \item{inline}{**ToDo!!!** }
#' \item{block}{**ToDo!!!** }
#' \item{list-item}{**ToDo!!!** }
#' \item{run-in}{**ToDo!!!** }
#' \item{compact}{**ToDo!!!** }
#' \item{marker}{**ToDo!!!** }
#' \item{table}{**ToDo!!!** }
#' \item{inline-table}{**ToDo!!!** }
#' \item{table-row-group}{**ToDo!!!** }
#' \item{table-header-group}{**ToDo!!!** }
#' \item{table-footer-group}{**ToDo!!!** }
#' \item{table-row}{**ToDo!!!** }
#' \item{table-column-group}{**ToDo!!!** }
#' \item{table-column}{**ToDo!!!** }
#' \item{table-cell}{**ToDo!!!** }
#' \item{table-caption}{**ToDo!!!** }
#' \item{none}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Graphics Referencing Elements}}{\code{\link[=image]{image}}, \code{\link[=use]{use}}}
#' \item{\emph{Non-structural Container Elements}}{\code{\link[=a]{a}}, \code{\link[=switch]{switch}}}
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Structural Container Elements}}{\code{\link[=g]{g}}, \code{\link[=svg]{svg}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' \item{\emph{Uncategorized Elements}}{\code{\link[=foreignObject]{foreignObject}}}
#' }
#' @keywords internal
NULL


#' @name visibility-presentationAttribute
#' @title visibility
#' @description 
#' Specifies whether the  current graphics element will be visible.
#' @section Available Attribute Values:
#' \itemize{
#' \item{visible}{**ToDo!!!** }
#' \item{hidden}{**ToDo!!!** }
#' \item{collapse}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Graphics Referencing Elements}}{\code{\link[=image]{image}}, \code{\link[=use]{use}}}
#' \item{\emph{Non-structural Container Elements}}{\code{\link[=a]{a}}}
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' }
#' @keywords internal
NULL


#' @name marker properties-presentationAttribute
#' @title marker properties
#' @description 
#' To do
#' @section Available Attribute Values:
#' \itemize{
#' \item{none}{**ToDo!!!** }
#' \item{<funciri>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Shape Elements}}{\code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}}
#' }
#' @keywords internal
NULL


#' @name marker-presentationAttribute
#' @title marker
#' @description 
#' Specifies the marker symbol that shall be used for all points on the sets the value for all vertices on the given ‘path’ element or basic shape.
#' @section Available Attribute Values:
#' \itemize{
#' \item{see individual properties}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Shape Elements}}{\code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}}
#' }
#' @keywords internal
NULL


#' @name color-interpolation-presentationAttribute
#' @title color.interpolation
#' @description 
#' Specifies the color space for gradient interpolations, color animations and alpha compositing.
#' @section Available Attribute Values:
#' \itemize{
#' \item{auto}{**ToDo!!!** }
#' \item{sRGB}{**ToDo!!!** }
#' \item{linearRGB}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Animation Elements}}{\code{\link[=animate]{animate}}, \code{\link[=animateColor]{animateColor}}}
#' \item{\emph{Graphics Referencing Elements}}{\code{\link[=image]{image}}, \code{\link[=use]{use}}}
#' \item{\emph{Non-structural Container Elements}}{\code{\link[=a]{a}}, \code{\link[=glyph]{glyph}}, \code{\link[=marker]{marker}}, \code{\link[=mask]{mask}}, \code{\link[=missing-glyph]{missing.glyph}}, \code{\link[=pattern]{pattern}}, \code{\link[=switch]{switch}}}
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Structural Container Elements}}{\code{\link[=defs]{defs}}, \code{\link[=g]{g}}, \code{\link[=svg]{svg}}, \code{\link[=symbol]{symbol}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=text]{text}}}
#' }
#' @keywords internal
NULL


#' @name color-interpolation-filters-presentationAttribute
#' @title color.interpolation.filters
#' @description 
#' Specifies the color space for imaging operations performed via filter effects.
#' @section Available Attribute Values:
#' \itemize{
#' \item{auto}{**ToDo!!!** }
#' \item{sRGB}{**ToDo!!!** }
#' \item{linearRGB}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Filter Primitive Elements}}{\code{\link[=feBlend]{feBlend}}, \code{\link[=feColorMatrix]{feColorMatrix}}, \code{\link[=feComponentTransfer]{feComponentTransfer}}, \code{\link[=feComposite]{feComposite}}, \code{\link[=feConvolveMatrix]{feConvolveMatrix}}, \code{\link[=feDiffuseLighting]{feDiffuseLighting}}, \code{\link[=feDisplacementMap]{feDisplacementMap}}, \code{\link[=feFlood]{feFlood}}, \code{\link[=feGaussianBlur]{feGaussianBlur}}, \code{\link[=feImage]{feImage}}, \code{\link[=feMerge]{feMerge}}, \code{\link[=feMorphology]{feMorphology}}, \code{\link[=feOffset]{feOffset}}, \code{\link[=feSpecularLighting]{feSpecularLighting}}, \code{\link[=feTile]{feTile}}, \code{\link[=feTurbulence]{feTurbulence}}}
#' }
#' @keywords internal
NULL


#' @name color-rendering-presentationAttribute
#' @title color.rendering
#' @description 
#' Specifies the color space for gradient interpolations, color animations and alpha compositing.
#' @section Available Attribute Values:
#' \itemize{
#' \item{auto}{**ToDo!!!** }
#' \item{optimizeSpeed}{**ToDo!!!** }
#' \item{optimizeQuality}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Animation Elements}}{\code{\link[=animate]{animate}}, \code{\link[=animateColor]{animateColor}}}
#' \item{\emph{Graphics Referencing Elements}}{\code{\link[=image]{image}}, \code{\link[=use]{use}}}
#' \item{\emph{Non-structural Container Elements}}{\code{\link[=a]{a}}, \code{\link[=glyph]{glyph}}, \code{\link[=marker]{marker}}, \code{\link[=mask]{mask}}, \code{\link[=missing-glyph]{missing.glyph}}, \code{\link[=pattern]{pattern}}, \code{\link[=switch]{switch}}}
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Structural Container Elements}}{\code{\link[=defs]{defs}}, \code{\link[=g]{g}}, \code{\link[=svg]{svg}}, \code{\link[=symbol]{symbol}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=text]{text}}}
#' }
#' @keywords internal
NULL


#' @name shape-rendering-presentationAttribute
#' @title shape.rendering
#' @description 
#' Specifies which tradeoff to use (auto | optimizeSpeed | crispEdges ) when rendering paths and basic shapes.
#' @section Available Attribute Values:
#' \itemize{
#' \item{auto}{**ToDo!!!** }
#' \item{optimizeSpeed}{**ToDo!!!** }
#' \item{crispEdges}{**ToDo!!!** }
#' \item{geometricPrecision}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' }
#' @keywords internal
NULL


#' @name text-rendering-presentationAttribute
#' @title text.rendering
#' @description 
#' Specifies which tradeoff to use (auto | optimizeSpeed | optimizeLegibility ) when rendering text.
#' @section Available Attribute Values:
#' \itemize{
#' \item{auto}{**ToDo!!!** }
#' \item{optimizeSpeed}{**ToDo!!!** }
#' \item{optimizeLegibility}{**ToDo!!!** }
#' \item{geometricPrecision}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Text Content Elements}}{\code{\link[=text]{text}}}
#' }
#' @keywords internal
NULL


#' @name image-rendering-presentationAttribute
#' @title image.rendering
#' @description 
#' Specifies which tradeoff to use (auto | optimizeSpeed | optimizeQuality) when rendering images.
#' @section Available Attribute Values:
#' \itemize{
#' \item{auto}{**ToDo!!!** }
#' \item{optimizeSpeed}{**ToDo!!!** }
#' \item{optimizeQuality}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Graphics Referencing Elements}}{\code{\link[=image]{image}}}
#' }
#' @keywords internal
NULL


#' @name color-presentationAttribute
#' @title color
#' @description 
#' Specifies a potential indirect value (currentColor) for the ‘fill’, ‘stroke’, ‘stop-color’, ‘flood-color’ and ‘lighting-color’ properties.
#' @section Available Attribute Values:
#' \itemize{
#' \item{<color>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Filter Primitive Elements}}{\code{\link[=feDiffuseLighting]{feDiffuseLighting}}, \code{\link[=feFlood]{feFlood}}, \code{\link[=feSpecularLighting]{feSpecularLighting}}}
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=altGlyph]{altGlyph}}, \code{\link[=text]{text}}, \code{\link[=textPath]{textPath}}, \code{\link[=tref]{tref}}, \code{\link[=tspan]{tspan}}}
#' \item{\emph{Uncategorized Elements}}{\code{\link[=stop]{stop}}}
#' }
#' @keywords internal
NULL


#' @name color-profile-presentationAttribute
#' @title color.profile
#' @description 
#' Specifies a source color profile
#' @section Available Attribute Values:
#' \itemize{
#' \item{auto}{**ToDo!!!** }
#' \item{sRGB}{**ToDo!!!** }
#' \item{<name>}{**ToDo!!!** }
#' \item{<iri>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Graphics Referencing Elements}}{\code{\link[=image]{image}}}
#' }
#' @keywords internal
NULL


#' @name pointer-events-presentationAttribute
#' @title pointer.events
#' @description 
#' Specifies under what circumstances a given graphics element can be the target element for a pointer event
#' @section Available Attribute Values:
#' \itemize{
#' \item{visiblePainted}{**ToDo!!!** }
#' \item{visibleFill}{**ToDo!!!** }
#' \item{visibleStroke}{**ToDo!!!** }
#' \item{visible}{**ToDo!!!** }
#' \item{painted}{**ToDo!!!** }
#' \item{fill}{**ToDo!!!** }
#' \item{stroke}{**ToDo!!!** }
#' \item{all}{**ToDo!!!** }
#' \item{none}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Graphics Referencing Elements}}{\code{\link[=image]{image}}, \code{\link[=use]{use}}}
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=text]{text}}}
#' }
#' @keywords internal
NULL


#' @name cursor-presentationAttribute
#' @title cursor
#' @description 
#' Specifies the type of cursor to be displayed for the pointing device.
#' @section Available Attribute Values:
#' \itemize{
#' \item{[ [<funciri> ,]* [ auto | crosshair | default | pointer | move | e-resize | ne-resize | nw-resize | n-resize | se-resize | sw-resize | s-resize | w-resize| text | wait | help ] ] | inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Graphics Referencing Elements}}{\code{\link[=image]{image}}, \code{\link[=use]{use}}}
#' \item{\emph{Non-structural Container Elements}}{\code{\link[=a]{a}}, \code{\link[=glyph]{glyph}}, \code{\link[=marker]{marker}}, \code{\link[=mask]{mask}}, \code{\link[=missing-glyph]{missing.glyph}}, \code{\link[=pattern]{pattern}}, \code{\link[=switch]{switch}}}
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Structural Container Elements}}{\code{\link[=defs]{defs}}, \code{\link[=g]{g}}, \code{\link[=svg]{svg}}, \code{\link[=symbol]{symbol}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=text]{text}}}
#' }
#' @keywords internal
NULL


#' @name filter-presentationAttribute
#' @title filter
#' @description 
#' Used to specify a reference to  the filter effects to be applied to the given container or graphical element.
#' @section Available Attribute Values:
#' \itemize{
#' \item{<funciri>}{**ToDo!!!** }
#' \item{none}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Graphics Referencing Elements}}{\code{\link[=image]{image}}, \code{\link[=use]{use}}}
#' \item{\emph{Non-structural Container Elements}}{\code{\link[=a]{a}}, \code{\link[=glyph]{glyph}}, \code{\link[=marker]{marker}}, \code{\link[=missing-glyph]{missing.glyph}}, \code{\link[=pattern]{pattern}}, \code{\link[=switch]{switch}}}
#' \item{\emph{Shape Elements}}{\code{\link[=circle]{circle}}, \code{\link[=ellipse]{ellipse}}, \code{\link[=line]{line}}, \code{\link[=path]{path}}, \code{\link[=polygon]{polygon}}, \code{\link[=polyline]{polyline}}, \code{\link[=rect]{rect}}}
#' \item{\emph{Structural Container Elements}}{\code{\link[=defs]{defs}}, \code{\link[=g]{g}}, \code{\link[=svg]{svg}}, \code{\link[=symbol]{symbol}}}
#' \item{\emph{Text Content Elements}}{\code{\link[=text]{text}}}
#' }
#' @keywords internal
NULL


#' @name enable-background-presentationAttribute
#' @title enable.background
#' @description 
#' Specifies how to manage the accumulation of background images of container elements.
#' @section Available Attribute Values:
#' \itemize{
#' \item{accumulate | new [ <x> <y> <width> <height> ] | inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Non-structural Container Elements}}{\code{\link[=a]{a}}, \code{\link[=glyph]{glyph}}, \code{\link[=marker]{marker}}, \code{\link[=mask]{mask}}, \code{\link[=missing-glyph]{missing.glyph}}, \code{\link[=pattern]{pattern}}, \code{\link[=switch]{switch}}}
#' \item{\emph{Structural Container Elements}}{\code{\link[=defs]{defs}}, \code{\link[=g]{g}}, \code{\link[=svg]{svg}}, \code{\link[=symbol]{symbol}}}
#' }
#' @keywords internal
NULL


#' @name lighting-color-presentationAttribute
#' @title lighting.color
#' @description 
#' Specifies the color of the light source for filter primitives feDiffuseLighting and feSpecularLighting.
#' @section Available Attribute Values:
#' \itemize{
#' \item{currentColor |<color> [<icccolor>] | inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Filter Primitive Elements}}{\code{\link[=feDiffuseLighting]{feDiffuseLighting}}, \code{\link[=feSpecularLighting]{feSpecularLighting}}}
#' }
#' @keywords internal
NULL


#' @name flood-color-presentationAttribute
#' @title flood.color
#' @description 
#' Specifies what color to use to flood the current filter primitive subregion.
#' @section Available Attribute Values:
#' \itemize{
#' \item{currentColor |<color> [<icccolor>] | inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Filter Primitive Elements}}{\code{\link[=feFlood]{feFlood}}}
#' }
#' @keywords internal
NULL


#' @name flood-opacity-presentationAttribute
#' @title flood.opacity
#' @description 
#' Specifies the opacity value to be used across the entire filter primitive subregion.
#' @section Available Attribute Values:
#' \itemize{
#' \item{<opacity-value>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Filter Primitive Elements}}{\code{\link[=feFlood]{feFlood}}}
#' }
#' @keywords internal
NULL


#' @name stop-color-presentationAttribute
#' @title stop.color
#' @description 
#' Specifies the color to achieve at the gradient stop position.
#' @section Available Attribute Values:
#' \itemize{
#' \item{currentColor}{**ToDo!!!** }
#' \item{<color> <icccolor>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Uncategorized Elements}}{\code{\link[=stop]{stop}}}
#' }
#' @keywords internal
NULL


#' @name stop-opacity-presentationAttribute
#' @title stop.opacity
#' @description 
#' Specifies the opacity  to achieve at the gradient stop position.
#' @section Available Attribute Values:
#' \itemize{
#' \item{<opacity-value>}{**ToDo!!!** }
#' \item{inherit}{**ToDo!!!** }
#' }
#' @section Used by the Elements:
#' \describe{
#' \item{\emph{Uncategorized Elements}}{\code{\link[=stop]{stop}}}
#' }
#' @keywords internal
NULL

