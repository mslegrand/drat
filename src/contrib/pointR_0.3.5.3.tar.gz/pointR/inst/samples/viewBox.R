#svgR elements: font-face glyph missing-glyph hkern vkern font font-face-name font-face-format font-face-uri animate animateColor animateMotion animateTransform set mpath feFuncA feFuncB feFuncG feFuncR feDistantLight feTurbulence feConvolveMatrix feDiffuseLighting feOffset filter feBlend feColorMatrix feComponentTransfer feComposite feDisplacementMap feFlood feGaussianBlur feImage feMerge feMorphology feSpecularLighting feTile feSpotLight fePointLight svg a altGlyph circle clipPath cursor defs ellipse foreignObject g image line linearGradient marker mask path pattern polygon polyline radialGradient rect script switch symbol text textPath tref tspan use view altGlyphDef altGlyphItem color-profile desc feMergeNode font-face-src glyphRef metadata stop style title font.face missing.glyph font.face.name font.face.format font.face.uri color.profile font.face.src translate rotate rotatR scale u.em u.ex u.px u.pt u.pc u.cm u.mm u.in u.prct u.rad
library(svgR)
WH<-c(1500,1500)

#Defined by mouse: edit with care!
ptR<-list(
  x=matrix(
    c(c( 202,223 ),c( 98,387 ),c( 562,99 )), 2
  ),
  y=matrix(
    c(c( 115,390 ),c( 548,112 )), 2
  )
)

px2ViewBox<-function(px,vb, xy, wh){
   vb<-matrix(vb,2)
   px<-vb[,1]+px-xy 
   scale<-vb[,2]/wh
   px*scale    
}

# define the viewport of the svg
xyb<-c(100,100)
whb<-c(400,200)


#define a viewbox for the svg
vb<- c(0,0,10,10)

xbPts<-px2ViewBox(ptR$x, vb,xyb, whb)
ybPts<-px2ViewBox(ptR$y, vb,xyb, whb)

svgR(wh=WH, 
#your custom code goes here
  svg(
      xy=xyb,
      wh=whb,
      viewBox= vb,
      preserveAspectRatio='none',
      polyline(points=matrix(c(0,0,5,5,10,0),2), fill='none', stroke='red'),
      rect(xy=c(0,0), wh=c(10,10), fill='none', stroke='black'),
      circle(cxy=xbPts[,1], r=2),
      polyline(points=ybPts, stroke='blue', fill='none')
              
  )
 



)

