
moduleTransformsUI<-function(id, input, output) { 
  ns <- NS(id)
  absolutePanel( top=50, left=0, width="100%", draggable=TRUE,
    tabsetPanel( ns("transformOption"), 
      tabPanel("Translate"), 
      tabPanel("Rotate"), 
      tabPanel("Scale"),
      type="pills"
    ) 
  )
} 

moduleTransforms<-function(
  input, output, session, 
  id2,
  barName, 
  getCode,
  getPtDefs
){
  
  
}


