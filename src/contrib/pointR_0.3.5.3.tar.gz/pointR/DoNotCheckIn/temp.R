#<dt><code>animate</code>
  
#<dt><code><a href=\"../../svgcreatoR/html/circle.html\">circle</a></code></dt>

#tmp='<a href=\"../../svgcreatoR/html/circle.html\">'

#pattern='<a href=\"[^\"])\"'
#http://127.0.0.1:42166/help/library/svgR/html/grapes-less-than-c-grapes.html

#txt<-"<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\"><head><title>R: Element Generators Indexed by Category</title>\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n<link rel=\"stylesheet\" type=\"text/css\" href=\"R.css\" />\n</head><body>\n\n<table width=\"100%\" summary=\"page for Elememt Index\"><tr><td>Elememt Index</td><td style=\"text-align: right;\">R Documentation</td></tr></table>\n\n<h2>Element Generators Indexed by Category</h2>\n\n<h3>Description</h3>\n\n<p>This is a listing by category of generators to use when generating an svg markup.\n</p>\n\n\n<h3>Animation Elements</h3>\n\n\n<dl>\n<dt><code>animate</code></dt><dd></dd>\n<dt><code>animateColor</code></dt><dd></dd>\n<dt><code>animateMotion</code></dt><dd></dd>\n<dt><code>animateTransform</code></dt><dd></dd>\n<dt><code>set</code></dt><dd></dd>\n</dl>\n\n\n\n<h3>Basic Shape Elements</h3>\n\n\n<dl>\n<dt><code>circle</code></dt><dd></dd>\n<dt><code>ellipse</code></dt><dd></dd>\n<dt><code>line</code></dt><dd></dd>\n<dt><code>polygon</code></dt><dd></dd>\n<dt><code>polyline</code></dt><dd></dd>\n<dt><code>rect</code></dt><dd></dd>\n</dl>\n\n\n\n<h3>Container Elements</h3>\n\n\n<dl>\n<dt><code>a</code></dt><dd></dd>\n<dt><code>defs</code></dt><dd></dd>\n<dt><code>g</code></dt><dd></dd>\n<dt><code>glyph</code></dt><dd></dd>\n<dt><code>marker</code></dt><dd></dd>\n<dt><code>mask</code></dt><dd></dd>\n<dt><code>missing.glyph</code></dt><dd></dd>\n<dt><code>pattern</code></dt><dd></dd>\n<dt><code>svg</code></dt><dd></dd>\n<dt><code>switch</code></dt><dd></dd>\n<dt><code>symbol</code></dt><dd></dd>\n</dl>\n\n\n\n<h3>Descriptive Elements</h3>\n\n\n<dl>\n<dt><code>desc</code></dt><dd></dd>\n<dt><code>metadata</code></dt><dd></dd>\n<dt><code>title</code></dt><dd></dd>\n</dl>\n\n\n\n<h3>Filter Primitive Elements</h3>\n\n\n<dl>\n<dt><code>feBlend</code></dt><dd></dd>\n<dt><code>feColorMatrix</code></dt><dd></dd>\n<dt><code>feComponentTransfer</code></dt><dd></dd>\n<dt><code>feComposite</code></dt><dd></dd>\n<dt><code>feConvolveMatrix</code></dt><dd></dd>\n<dt><code>feDiffuseLighting</code></dt><dd></dd>\n<dt><code>feDisplacementMap</code></dt><dd></dd>\n<dt><code>feFlood</code></dt><dd></dd>\n<dt><code>feGaussianBlur</code></dt><dd></dd>\n<dt><code>feImage</code></dt><dd></dd>\n<dt><code>feMerge</code></dt><dd></dd>\n<dt><code>feMorphology</code></dt><dd></dd>\n<dt><code>feOffset</code></dt><dd></dd>\n<dt><code>feSpecularLighting</code></dt><dd></dd>\n<dt><code>feTile</code></dt><dd></dd>\n<dt><code>feTurbulence</code></dt><dd></dd>\n</dl>\n\n\n\n<h3>Gradient Elements</h3>\n\n\n<dl>\n<dt><code>linearGradient</code></dt><dd></dd>\n<dt><code>radialGradient</code></dt><dd></dd>\n</dl>\n\n\n\n<h3>Graphics Elements</h3>\n\n\n<dl>\n<dt><code>circle</code></dt><dd></dd>\n<dt><code>ellipse</code></dt><dd></dd>\n<dt><code>image</code></dt><dd></dd>\n<dt><code>line</code></dt><dd></dd>\n<dt><code>path</code></dt><dd></dd>\n<dt><code>polygon</code></dt><dd></dd>\n<dt><code>polyline</code></dt><dd></dd>\n<dt><code>rect</code></dt><dd></dd>\n<dt><code>text</code></dt><dd></dd>\n<dt><code>use</code></dt><dd></dd>\n</dl>\n\n\n\n<h3>Graphics Referencing Elements</h3>\n\n\n<dl>\n<dt><code>image</code></dt><dd></dd>\n<dt><code>use</code></dt><dd></dd>\n</dl>\n\n\n\n<h3>Light Source Elements</h3>\n\n\n<dl>\n<dt><code>feDistantLight</code></dt><dd></dd>\n<dt><code>fePointLight</code></dt><dd></dd>\n<dt><code>feSpotLight</code></dt><dd></dd>\n</dl>\n\n\n\n<h3>Shape Elements</h3>\n\n\n<dl>\n<dt><code>circle</code></dt><dd></dd>\n<dt><code>ellipse</code></dt><dd></dd>\n<dt><code>line</code></dt><dd></dd>\n<dt><code>path</code></dt><dd></dd>\n<dt><code>polygon</code></dt><dd></dd>\n<dt><code>polyline</code></dt><dd></dd>\n<dt><code>rect</code></dt><dd></dd>\n</dl>\n\n\n\n<h3>Structural Elements</h3>\n\n\n<dl>\n<dt><code>defs</code></dt><dd></dd>\n<dt><code>g</code></dt><dd></dd>\n<dt><code>svg</code></dt><dd></dd>\n<dt><code>symbol</code></dt><dd></dd>\n<dt><code>use</code></dt><dd></dd>\n</dl>\n\n\n\n<h3>Text Content Child Elements</h3>\n\n\n<dl>\n<dt><code>altGlyph</code></dt><dd></dd>\n<dt><code>textPath</code></dt><dd></dd>\n<dt><code>tref</code></dt><dd></dd>\n<dt><code>tspan</code></dt><dd></dd>\n</dl>\n\n\n\n<h3>Text Content Elements</h3>\n\n\n<dl>\n<dt><code>altGlyph</code></dt><dd></dd>\n<dt><code>text</code></dt><dd></dd>\n<dt><code>textPath</code></dt><dd></dd>\n<dt><code>tref</code></dt><dd></dd>\n<dt><code>tspan</code></dt><dd></dd>\n</dl>\n\n\n\n<h3>Uncategorized Elements</h3>\n\n\n<dl>\n<dt><code>altGlyphDef</code></dt><dd></dd>\n<dt><code>altGlyphItem</code></dt><dd></dd>\n<dt><code>clipPath</code></dt><dd></dd>\n<dt><code>color.profile</code></dt><dd></dd>\n<dt><code>cursor</code></dt><dd></dd>\n<dt><code>feFuncA</code></dt><dd></dd>\n<dt><code>feFuncB</code></dt><dd></dd>\n<dt><code>feFuncG</code></dt><dd></dd>\n<dt><code>feFuncR</code></dt><dd></dd>\n<dt><code>feMergeNode</code></dt><dd></dd>\n<dt><code>filter</code></dt><dd></dd>\n<dt><code>font</code></dt><dd></dd>\n<dt><code>font.face</code></dt><dd></dd>\n<dt><code>font.face.format</code></dt><dd></dd>\n<dt><code>font.face.name</code></dt><dd></dd>\n<dt><code>font.face.src</code></dt><dd></dd>\n<dt><code>font.face.uri</code></dt><dd></dd>\n<dt><code>foreignObject</code></dt><dd></dd>\n<dt><code>glyphRef</code></dt><dd></dd>\n<dt><code>hkern</code></dt><dd></dd>\n<dt><code>mpath</code></dt><dd></dd>\n<dt><code>script</code></dt><dd></dd>\n<dt><code>stop</code></dt><dd></dd>\n<dt><code>style</code></dt><dd></dd>\n<dt><code>view</code></dt><dd></dd>\n<dt><code>vkern</code></dt><dd></dd>\n</dl>\n\n\n\n</body></html>"

# txt<-"xxabcyy"
# pattern<-regexpr("([abc]+)", txt, perl=T)
# tmp<-regmatches(txt,pattern)
# print(tmp)


# txt<-"xxabcyy"
# print(txt)
# pattern<-regexpr("xx([^y]*)yy", txt, perl=T)
# tmp<-regmatches(txt,pattern)
# print(tmp)
# 
# replacement<-'xx<a onclick="helpSvgR(\"\1\")>\1</a>yy'
# replacement<-'uu\1uu'
# txt2<-gsub(pattern, replacement, txt, perl=TRUE )
# cat(txt2)


txt<-'<h3>Basic Shape Elements</h3>\n\n\n<dl>\n<dt><code>circle</code></dt><dd></dd>\n<dt><code>ellipse</code></dt><dd></dd>\n<dt><code>line</code></dt><dd></dd>\n<dt><code>polygon</code></dt><dd></dd>\n<dt><code>polyline</code></dt><dd></dd>\n<dt><code>rect</code></dt><dd></dd>\n</dl>\n\n\n\n'
#pattern='(<dt><code>[^<]+</code><dt>)'
pattern='(<dt><code>([^<]+)</code></dt>)'
replace='<dt><code><a onclick="helpSvgR(\'\\2\')" >(\\2)</a></code></dt>'

#replace="xxx"
txt2<-gsub(pattern=pattern, replacement=replace, x=txt, perl=FALSE)
cat(txt2)

