
#currently update triggers value from choice to ace
# propose
moduleTagValUI<-function(id, input, output) { 
  ns <- NS(id)
  #useShinyjs()
  absolutePanel( 
    top=50, left=0, width="100%", "class"="headerPanel", draggable=FALSE,
    div(style="display:inline-block",
      selectInput( ns("name"), "Point Matrix",
      multiple=FALSE, size=1, selectize = FALSE,
      choices=list(),  selected=NULL, width="80px"  )
    ),
    div(style="display:inline-block",
        selectInput(ns("index"), "Tag-No",
                    multiple=FALSE, size=1, selectize = FALSE, 
                    choices=list(), selected=NULL, width="60px"  )
    ), 
    div(style="display:inline-block",
      selectInput(ns("attrName"), label="Attribute",
      multiple=FALSE, size=1, selectize = FALSE, 
      choices=list(),  selected=NULL, width="120px"  )
    ),
    div(style="display:inline-block", 
      selectInput(ns("attrVal"), "Value", 
      multiple=FALSE, size=1, selectize = FALSE,  
      choices=list(),  selected=NULL, width="100px"  )
    ),
    div(style="display:inline-block",
      actionButton(ns( "New" ), label = "New") #buttonSmall
    ),
    div(style="display:inline-block",
        actionButton(ns( "updateVal" ), label = "Update") #buttonSmall
    )
  ) # panel end
}

moduleTagVal<-function(input, output, session, 
  id2,
  barName, 
  getCode,
  getPtDefs,
  getTagNameChoices,
  getTagName, 
  getTagIndexChoices,
  getTagIndex
){
  ns<-NS(id2)
  localReactive<-reactiveValues( 
    tagRList = NULL,
    tagRFrame= NULL,
    names=NULL,
    updateTagsNow =0,
    attribute=NULL
  )
  
  #=== utils
  safeChoice<-function(curChoice, choices){
    if( is.null(curChoice) || (!(curChoice %in% choices)) ){
      return(tail(choices,1))
    }
    curChoice
  }
  safeAttrChoices<-function(tagRFrame){
    if(is.null(tagRFrame)){
      NULL
    } else{
      setdiff(names(tagRFrame), "tag")
    }
  }
  safeIndxChoices<-function(tagRFrame){
    if(is.null(tagRFrame)){
      NULL
    } else {
      tagRFrame$tag
    }
  }
  safeValueChoices<-function(tagRFrame, attr){
    if(is.null(attr)){
      NULL
    } else {
      sort(unique(tagRFrame[[attr]]))
    }
  }
  safeValue<-function(tagRFrame, attr, index){
    if(
      all(!sapply(list(tagRFrame,attr,index), is.null))
    ){
      value<-tagRFrame[tagRFrame$tag==index, attr]
    } else {
      value<-NULL
    }
    value
  }
  
  #if change from outside
  observeEvent( getPtDefs(),{
    localReactive$tagRList<-getPtDefs()$df
    tagRList<-getPtDefs()$df
    name<-input$name
    nameChoices<-names(tagRList)
    if(!is.null(name)){
      name<-safeChoice(name, nameChoices )
    } else {
      name<-getTagName()
      name<-safeChoice(name, nameChoices )
    }
    if( input$name==name ){
      if(!is.null(name))
        localReactive$tagRFrame<-localReactive$tagRList[[name]]
      else
        localReactive$tagRFrame<-NULL
    } else {
      updateSelectInput( 
        session, input$name,
        choices=nameChoices,
        selected=name
      )
    }
  })
  
  #if name change update tagRFrame
  observeEvent(input$name,{
    if(!is.null(name)){
      localReactive$tagRFrame<-localReactive$tagRList[[name]]
    } else {
      localReactive$tagRFrame<-NULL
    }
  })
  
  #if tagRFrame changes because of either
  # name or tagRlist change.
  observeEvent(localReactive$tagRFrame,{
    name<-index$name
    if(!is.null(localReactive$tagRFrame)){
      # initial attributes
      attr<-input$attr
      attrChoices<-safeAttrChoices(tagRFrame)
      attr<-safeChoice(attr, attrChoices )
      # initial indices (tags)
      index<-input$index
      indexChoices<-safeIndxChoices(tagRFrame)
      index<-safeChoice(index, indexChoices)
      
      if(input$attr==attr && input$index==index){
        valueChoices<-safeValueChoices(tagRFrame, attr)
        value<-safeValue(tagRFrame, attr, index)
        updateSelectInput( 
          session, input$value,
          choices=valueChoices,
          selected=value
        )
      }
      updateSelectInput( 
        session, input$attr,
        choices=attrChoices,
        selected=attr
      )
      updateSelectInput( 
        session, input$index,
        choices=indexChoices,
        selected=index
      )
    }
  })
  
  observeEvent()
  
   
  #===
  # this should be updated whenever 
  # 1) we change to this page
  # or 
  # 2) we change the code/ptDefs, 
  # ???should not use getPtDefs???
  
  observeEvent( getPtDefs(),{
    localReactive$tagRList<-getPtDefs()$df
    tagRList<-getPtDefs()$df
    
    # initial values of inputs
    
    name<-input$name
    attr<-input$choice
    index<-input$index
    nameChoices<-names(tagRList)
    
    if(is.null(name)){
      name<-getTagName() #todo!!! replace with server::selection$name
    }
    name<-safeChoice(name, nameChoices )
    # initial attributes
    attrChoices<-safeAttrChoices(tagRList, name)
    attr<-safeChoice(attr, attrChoices )
    # initial indices (tags)
    indexChoices<-safeIndxChoices(tagRList, name)
    index<-safeChoice(index, indexChoices)
    # initial values
    valueChoices<-safeValueChoices(tagRList, name, attr)
    value<-safeValue(tagRList, name, attr, index)
    
    #now update
    updateSelectInput( 
      session, input$name,
      choices=nameChoices,
      selected=name
    )
    updateSelectInput( 
      session, input$attrName,
      choices=attrChoices,
      selected=attr
    )
    updateSelectInput( 
      session, input$index,
      choices=indexChoices,
      selected=index
    )
    updateSelectInput( 
      session, input$value,
      choices=valueChoices,
      selected=value
    )
  })
  
  #===
  getName<-reactive({input$name})
  getIndex<-reactive({input$index})
  
  #===
  getDF<-reactive({
    # should use localReactive$tagRList instead of getPtDefs()$df ???
    if(
      !is.null(getName()) && 
      !is.null( localReactive$tagRList ) && 
      getName() %in% names(localReactive$tagRList)  
    ){
      localReactive$tagRList[[getName()]] 
    } else {
      NULL
    }
  })
  
  #=== attr choices
  #get attribute choices, uses DF from localReactive$tagRList
  # and name from input$name
  getTagColChoices<-reactive({
    df<-getDF()
    if(!is.null(df)){
      tagColChoices<-setdiff(names(df),"tag")
    } else {
      NULL
    }
  })
  
  
  #=== attr selelection
  # gets attribute selection, input$attribName (ie. input$attrib)
  # trigger by:
  # 1) input$attrName
  # 2) getTagColChoices() 
  getTagCol<-reactive({  
    #isolate({print("getTagCol")})
    choices<-getTagColChoices() #grabs from local df
    attribute<-localReactive$attribute
    if(length(choices)==0){
        attribute<-NULL
    } 
    if( 
        is.null(attribute) ||
        (!(attribute %in% choices) 
    ){
       attribute<-tail(choices,1)
    }
    if(is.null(attribute) || !(attribute %in% localReactive$attribute)){
        localReactive$attribute<-attribute
    }
    return(attribute)
    
    if(!is.null(localReactive$attribute)){
        tmp<-localReactive$attribute  
        isolate({localReactive$attribute<-NULL})
        return(tmp)
    }
    if(length(choices)>0 && 
       length(input$attrName)>0 &&
       input$attrName %in% choices)
    {
      input$attrName
    } else {
      tail(choices,1)
    }
  })  
  
  #!!! getTagValueVector and getTagValueChoices are identical !!!
  getTagValueChoices<-reactive({
    #isolate({print("getTagValuesChoices")})
    if(length(getTagCol())>0  &&
      length(getDF)>0){
      getDF()[[getTagCol()]]
    } else {
      NULL
    }
  })
  
  getTagValue<-reactive({
    if(length(getTagValueChoices())>0){
      ptIndx<-getIndex()
      tags<-getDF()$tag
      indx<-which(ptIndx==tags)
      getTagValueChoices()[[indx]]
    }
  })
  
  # updates the name selection using data from server.R
  observe({ #update the name 
    if(identical( barName(), 'tagValues')){
      tagNameChoices<-getTagNameChoices() # passed in from server
      tagName<-getTagName() # passed in from server
      updateSelectInput(
        session, 
        "name", 
        choices=tagNameChoices, 
        selected=tagName
      )
    } 
  })  
  
  #update tag index using data from server.R 
  observe({ #update index and choices
     if(identical( barName(), 'tagValues')){
      tagIndxChoices<-getTagIndexChoices() #passed in from server
      tagIndx<-getTagIndex() # passed in from server
      updateSelectInput(
        session, 
        "index", 
        choices=tagIndxChoices, 
        selected=tagIndx
      )
    } 
  }) 
  
  # update attrName (attribute)
  # conditional on: barName(), 
  # triggered by:
  # 1) getTagColChoices (local$name and local$tagList changes)
  # 2) getTagCol
  # sets attributeName
  # note triggering occurs after new attribute
  observe({ #tab col selection
    if(identical( barName(), 'tagValues')){
      tagColChoices<-getTagColChoices()
      tagCol<-getTagCol()
      updateSelectInput(session, "attrName", choices=tagColChoices)
      updateSelectInput(session, "attrName",  selected=tagCol)
    }
  })
  
  #updates the value using the DF 
  # conditional on: barName
  # triggered by: 
  # 
  observe(
    { #tag val selection
    if(identical( barName(), 'tagValues')){
      #print("inside observe barName")
      tagValueChoices<-getTagValueChoices()
      tagValue<-getTagValue()
      updateSelectInput(session, "attrVal", 
        choices=tagValueChoices, 
        selected=tagValue
      )
    }    
  })
  
  
  # triggered by pressing "Update" button
  observeEvent(
    input$updateVal,
    {
      if(identical( barName(), 'tagValues')){
        if(
          !is.null(localReactive$tagRList) && nchar(input$name)>0 && 
          length(input$attrName)>0 && length(input$index)>0 &&
          length(input$attrVal)>0
        )
        {
          tagValueVec<-  localReactive$tagRList[[input$name]][[input$attrName]]
          tags<-localReactive$tagRList[[input$name]]$tag
          tmp<-as.integer(input$index)
          indx<-which(tmp==tags)
          tagValueVec[indx]<-input$attrVal
          localReactive$tagRList[[input$name]][[input$attrName]]<-tagValueVec
          localReactive$updateTagsNow<-localReactive$updateTagsNow+1
        }
      }
    }
  )
  
  
  
  # Return the UI for a modal dialog with data selection input. I
  attrValueModal <- function(attrName, failedName=FALSE, failedValue=FALSE) {
    doOk<-paste0(
      "function(event){if(event.keyCode==13){ $(\"#",
      ns("ok"),
      "\").click()}}"
    )
    doOk<-"alert(''+ event.keyCode)"
    doOk<-paste0(
      'shinyjs.triggerButtonOnEnter(event,"',
      ns("ok"), 
      '")')
    modalDialog( 
      #div( 
      onkeypress=doOk,
      textInput(ns("modalAttrName"), "Attribute Name", value=attrName),
      textInput(ns("modalAttrValue"), "New Attribute Value" ), 
      span('Enter new choice for the given named attribute'),
      #),
      if (failedName)
        div(tags$b("Invalid Attribute Name: must begin with a character", style = "color: red;")),
      if (failedValue)
        div(tags$b("Invalid Attribute Value: must begin with printable character other than space", style = "color: red;")),
      easyClose = TRUE,
      footer = tagList(
        modalButton("Cancel"),
        actionButton(
          ns("ok"), 
          "Submit"
        )
      )
    )
  }
  
  #invokes modal for new attribute
  observeEvent(input$New,{
    attrName<-input$attrName
    showModal( attrValueModal(attrName ) ) 
  })
  
  observe( {
    localReactive$attribute
    if(!is.null(localReactive$attribute)){
      choices = getTagColChoices()
      selected=localReactive$attribute
      updateSelectInput(session, "attrName", #fails to work for some reason
                        choices=choices,
                        selected=selected)
    }
  })
  # 
  
  
  #dialog box ok handler
  observeEvent(input$ok, {
    if(identical( barName(), 'tagValues')){
      if( length(input$name)>0 &&  
          length(input$index)>0 &&
          !is.null(localReactive$tagRList)
      ){
        nameOK<-grepl(pattern = "^[[:alpha:]]", input$modalAttrName) && input$modalAttrName!="tag"
        valueOK<-grepl(pattern = "^[[:graph:]]", input$modalAttrValue)
        if( nameOK && valueOK){
            tagAttrNames<-  names(localReactive$tagRList[[input$name]])
            modalAttrName<-input$modalAttrName
            browser()
            tags<-localReactive$tagRList[[input$name]]$tag
            if(modalAttrName %in% tagAttrNames){
              tagValueVec<-localReactive$tagRList[[input$name]][[modalAttrName]]
              tmp<-as.integer(input$index)
              indx<-which(tmp==tags)
              tagValueVec[indx]<-input$modalAttrValue 
              isolate({print("update attrName 2")})
              updateSelectInput(
                session,
                inputId="attrName", #fails to update
                selected=modalAttrName
              )

            } else { #this is a new attributeName
              tagValueVec<-rep( input$modalAttrValue, length(tags) ) 
              tagAttrNames<-c(tagAttrNames,modalAttrName)
              updateSelectInput(
                session, 
                  inputId="attrName",  #fails to update
                  choices=tagAttrNames, 
                  selected=modalAttrName
                ) 
            }
            localReactive$attribute<-modalAttrName
            localReactive$tagRList[[input$name]][[modalAttrName]]<-tagValueVec
            localReactive$updateTagsNow<-localReactive$updateTagsNow+1
            removeModal()
      } else { # invalid modal input
          modalAttrName<-input$modalAttrName
          showModal(attrValueModal(modalAttrName, 
              failedName=!nameOK, failedValue=!valueOK) )
        }
      } #else ignore
    }
  })
  

  #when name, index, attrName valid, and attrVal changes, update the ptDefs and code
  list( 
    name      =reactive({input$name}),
    index     =reactive({input$index}),
    tagRList  =reactive({localReactive$tagRList}),
    updateTagsNow =reactive({localReactive$updateTagsNow})
    )
}