ace.define("ace/snippets/ptr",["require","exports","module"],function(e,t,n){
    t.snippetText=[ "#includes", "snippet lib","library(${1:package})"].join("\n");
    t.scope="ptr";
});