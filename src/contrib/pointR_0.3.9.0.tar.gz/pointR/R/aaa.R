
#' pointR
#' 
#' @name pointR
#' @docType package
#' @import shiny shinyjs  R.utils  svgR  shinyAce  stringr  jsonlite  shinyDMDMenu  shinyFiles  shinythemes colourpicker
#' NULL